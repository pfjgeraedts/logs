/* SPDX-License-Identifier: MIT */
/*
 * Copyright © 2020 Intel Corporation
 */

#ifndef __INTEL_MIGRATE_TYPES__
#define __INTEL_MIGRATE_TYPES__

struct intel_context;

struct intel_migrate {
	struct intel_context *context;
};

#endif /* __INTEL_MIGRATE_TYPES__ */
