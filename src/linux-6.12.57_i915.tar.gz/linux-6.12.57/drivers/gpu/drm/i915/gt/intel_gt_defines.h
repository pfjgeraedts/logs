/* SPDX-License-Identifier: MIT */
/*
 * Copyright © 2019 Intel Corporation
 */

#ifndef __INTEL_GT_DEFINES__
#define __INTEL_GT_DEFINES__

#define I915_MAX_GT 2

#endif
