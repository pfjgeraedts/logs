/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright © 2019 Intel Corporation
 */

#ifndef SELFTEST_ENGINE_H
#define SELFTEST_ENGINE_H

struct intel_gt;

int live_engine_pm_selftests(struct intel_gt *gt);

#endif
