// SPDX-License-Identifier: GPL-2.0
/*
 * Copyright © 2021 Intel Corporation
 */

#ifndef __CHECKER__
#define CREATE_TRACE_POINTS
#include "intel_display_trace.h"
#endif
